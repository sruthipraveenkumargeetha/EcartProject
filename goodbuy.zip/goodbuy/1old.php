
<!DOCTYPE html>
<html>
	<head>
		<title>WOMEN'S FASHION | GOOD BUY - YOUR ONE PLACE FOR EVERYTHING</title>
		<link rel="stylesheet" type="text/css" href="homepage.css">
		<style>
.sidenav {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color:#50d644;
    overflow-x: hidden;
    transition: 0.5s;
    padding-top: 60px;
}

.sidenav a {
    padding: 8px 8px 8px 32px;
    text-decoration: none;
    font-size: 15px;
    color: black;
    display: block;
    transition: 0.3s;
}

.sidenav a:hover {
    color:yellow;
}

.sidenav .closebtn {
    position: absolute;
    top: 0;
    right: 25px;
    font-size: 36px;
    margin-left: 50px;
}

</style>	
	</head>
	<body>
	
		<div id="nav">
	<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">Forever 21</a>
  <a href="#">Pantaloons</a>
  <a href="#">Chemistry</a>
  <a href="#">Lakme</a>
   <a href="#">Nivea</a>
<a href="#">Catwalk</a>

<a href="#">Fastrack</a>
<a href="#">Divastri</a>

<a href="#">Anmi</a>

<a href="#">Gold Coins</a>

</div>

<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;</span>

<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
</script>
				<ul style="font-size:15px;text-decoration:none;text-align:right;">
					<li><a href="">SellOnGoodBuy</a></li>
					<li><a href="">Advertise</a></li>
					
					<li><a href="">GiftCard</a></li>
					<li><a href="">24X7CustomerCare</a></li>
					<li><a href="">TrackOrder</a></li>
					<li><a href="">SignUp</a></li>
					<li><a href="">Login</a></li>
					

				</ul>
			</div>
		
			<div id="header" style="text-align:center;">
			
			
        			<div id="headerTitle" style="float:left"><a href="homepage.html"><img src="images/homepage/goodbuy.jpg"></a></div>
            			
        			<br><br><br><br>
				<div id="search" style="float:center;display:inline;vertical-align: middle;" >
		<form class="example" action="/action_page.php" style="margin:auto;max-width:300px;">
  <input type="text" placeholder="Search for products,brands and more..." name="search2">
  
</form>				</div>
		</div>
   			<br>
			<div id="nav">
				<ul style="font-size:15px;text-decoration:none;">
					<li style="color:white;"> Go quickly to --></li>
					<li><a href="">WinterWear</a></li>
					<li><a href="">Geysers</a></li>
					<li><a href="">NewBooks</a></li>
					<li><a href="">TVs</a></li>
					<li><a href="">Laptops</a></li>
					<li><a href="">Powerbank</a></li>
					<li><a href="">Sarees</a></li>
					<li><a href="">Kurtas&Kurtis</a></li>
					<li><a href="">Stationery</a></li>
					<li><a href="">Fitness</a></li>
					<li><a href="">Car accessories</a></li>
					
				</ul>
			</div>
		</div>
<div class="zoomin">
		<div id="content" style="text-align:center;overflow:visible;height:500px;">
			<div class="article column1">
				<a href="#"><img src="images/women/w1.jpg"></a>
				<form class="but" action="fpage.html"><br><br>
    					<input type="submit" value="ChristyWorld Sleeved Jacket" />
				</form>
			</div>
			<div class="article column2">
				<a href="#"><img src="images/women/w2.jpg"></a>
				<form class="but" action="#"><br><br>
    					<input type="submit" value="Ethinc Salwar Set" />
				</form>
			</div>
			<div class="article column3">
				<a href="#"><img src="images/women/w3.jpg"></a>
				<form class="but" action="#"><br><br>
    					<input type="submit" value="Mourya's Salwar Set" />
				</form>
			</div>
			<div class="article column4">
				<a href="#"><img src="images/women/w4.jpg"></a>
				<form class="but" action="#"><br>
    					<input type="submit" value="Vogueish Freyly Wear" />
				</form>
			</div>
			<div class="article column5">
				<a href="#"><img src="images/women/w5.jpg"></a>
				<form class="but" action="#"><br><br>
    					<input type="submit" value="HarpaFloral Denim Skirt" />
				</form>
			</div>
			<div class="article column1">
				<a href="#"><img src="images/women/w6.jpg"></a>
				<form class="but" action="#"><br><br>
    					<input type="submit" value="Edmiral FLowing SilkGown" />
				</form>
			</div>
			
			<div class="article column2">
				<a href="#"><img src="images/women/w7.jpg"></a>
				<form class="but" action="#"><br>
					<br>
    					<input type="submit" value="Rajadhani Salwar Suite" />
				</form>
			</div>
			<div class="article column3">
				<a href="#"><img src="images/women/w8.jpg"></a>
				<form class="but" action="#"><br>
    					<input type="submit" value="KenlyHart Western Wear" />
				</form>
			</div>
			<div class="article column4">
				<a href="#"><img src="images/women/w9.jpg"></a>
				<form class="but" action="#">
    					<input type="submit" value="Jodhpur Silk Salwar" />
				</form>
			</div>
			<div class="article column5">
				<a href="#"><img src="images/women/w10.jpg"></a>
				<form class="but" action="#"><br><br>
    					<input type="submit" value="Mayapuri Kotta Set" />
				</form>
			</div>
			
				
	</div>		
			
			
		</div>
		
		


		
			
			

 
		
		
		
		
		<div id="footer">
			<p> &copy; Copyright 2018</p>
		</div>
	</body>
</html>

