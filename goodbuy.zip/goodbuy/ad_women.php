<php?
session_start();
?>


<html>
<head>

<style>

 
*{
font-family: Comic Sans MS;

}
body{
background-color:#efefef;
}
img{border-radius:20%;}
td{text-align:center;
}
table,td,th{
border-collapse:collapse;
}
table,th{border:none;}
</style>
</head>
</html>

<html>
<head>
<style>
.button1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.button2{
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;
background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;

}
.button3{
 
   
     position:relative;
     bottom:0;
     
background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 12px;
    margin:50px;
    cursor: pointer;


}
.button4{
 position:relative;
     bottom:0;float:right;
     margin:50px;
background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 12px;
    
    cursor: pointer;


}
a{

text-decoration:none;
color:black;
}
</style>
</head>
<body>
<a href='admin_menu.html' class='button1'>BACK TO MENU</a>


<a href='homepage.php' class='button2'>LOG OUT</a>
</body>
</html>


<?php
session_start();

echo "				
				<div class='full-width-background fwb-red'></div>";

			
$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$custid=$_SESSION["email"];
$sql="SELECT * FROM women";
$category=1;
$result=$conn->query($sql);
echo "<form action='delete_women.php' method='post'>";

echo "<table align='center' border='1' width='90%' cellpadding='10'>";
echo "<th>  ITEM ID </th>  <th> ITEM NAME </th>  <th> ITEM RATE </th> <th> ITEM SIZE</th> <th> ITEM RATE </th><th> DISPLAY </th><th> DELETE </th>";
$i=0;
if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{	echo "<tr>";$i=$i+1;
		$id=row["itemid"];$name=$row["itemname"];$path=$row["path"];$rate=$row["itemrate"];$size=$row["size_availbale"];
		$url=$i.".php";
		echo "<td width='20%'>$i</td>  <td width='30%'>$name</td><td width='30%'>$rate</td><td width='30%'>$size</td> <td width='40%'><img src='$path'></td>
		 <td width='10%'><input type='checkbox' name='bag[]' value=$name />
</td>  <br><br> ";
	
		echo "</tr>";
		
        }
        
}
else
        echo "<br>";
echo "</table>";
echo "<input type='submit' name='formSubmit' value='DELETE ITEMS' class='button4'/>";
echo "</form>";
echo "<a href='insert_women.php' ><button class='button3'>INSERT ITEMS</button> </a>";

$conn->close() ;

?>

