<?php
// Start the session
session_start();
?>



<!DOCTYPE html>
<html>
	<head>

    <meta name="viewport">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">



		<title>GOOD BUY - YOUR ONE PLACE FOR EVERYTHING</title>
		<style type="text/css">
			* {
				font-family: Comic Sans MS;
						
				}
		body {
				width: 99%;background-color:ffffff;
				margin: 0 auto;}
		div{border-radius:2%;}
		a{text-decoration:none;}
		img{border-radius:40%}
			
		a:link {
    			color:#f2583a ;
			}



		a:hover {
    			color: white;
			}


		a:active {
    			color: white;
			}
			#trendy{margin:5px;}
	                #content{height:100%;}
			#nav, #feature, #footer {
				margin: 0.5%;}
			.column1, .column2, .column3,.column4,.column5 {
				width: 18%;
				height:50%;
				float: left;
				margin: 1%;}
			.column5 {
				margin-right: 0%;}
			li {
				display: inline;
				padding: 0.5em;
				}
			#nav,#downtips,#trendy {
				background-color:#efefef;
				padding: 0.5em 0;}
			#feature, .article {
				height: 20em;
				margin-bottom: 1em;
				background-color: #efefef;}
#dp{
border-radius:50%;width:50px;height:50px;
}
			
			h1{ 
				font-size:50px;
				text-align:left;
				padding-left:10px;
				
				float:up;
				}
			
			#footer{background-color: grey;
				padding:0.5px;}
			#downtips{text-align:left;font-size:12px;}
			#downtips,#trendy{padding:2px;}
			#headerTitle
			{
				position:relative;
				text-align:left;
				top:14px;	
				left:22px;
				font-size:50px;
				
			}
			box-sizing: border-box;
			ul a{text-decoration:none;}

			#headerSubtext
			{
				position:relative;
				text-align:left;
				top:12px;
				left:22px;
				font-size:14px;
				color:#25060B;
				font-family:"Adobe Garamond Pro Bold", Georgia, "Times New Roman", Times, serif;
			}
			.downhd{font-size:15px;}
		

.zoomin img { height: 200px; width: 200px; -webkit-transition: all 2s ease; -moz-transition: all 2s ease; -ms-transition: all 2s ease; transition: all 2s ease; } 

.zoomin img:hover { width: 225px; height: 225px; }

form.example::after {
    content: "";
    clear: both;
    display: table;
}

#f,#t,#t,#y{float:center;display:inline;padding:10px;}

		input[type=text], input[type=password] {
    width: 70%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 50%;
    opacity: 0.9;
}

button:hover {
    opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
    padding: 14px 20px;
    background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  
}

/* Add padding to container elements */
.container {
    padding: 16px;
}

/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: #474e5d;
    padding-top: 50px;
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
}

/* Style the horizontal ruler */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
    position: absolute;
    right: 35px;
    top: 15px;
    font-size: 40px;
    font-weight: bold;
    color: #f1f1f1;
}

.close:hover,
.close:focus {
    color: #f44336;
    cursor: pointer;
}

/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
    .cancelbtn, .signupbtn {
       width: 70%;
    }
}	
		</style>
	</head>
	<body>
		<div id="nav">

				<ul style="font-size:15px;text-decoration:none;text-align:right;">

					<li>
			<?php	echo " HAPPY SHOPPING <b> ".$_SESSION['fname']."</b>";?>
					</li> 
&nbsp
		
						<li>
<a href="changedp.php" style="text-decoration:none;color:white;"><?php $path=$_SESSION["path"];echo "<img src='$path' id='dp'> "?></a></li>
				 
						<li>
<button  style="width:auto;"><a href="dashboard.php" style="text-decoration:none;color:white;">DASH BOARD</a></button></li>
					
		<li>
<button  style="width:auto;"><a href="cust_category.php" style="text-decoration:none;color:white;">CATALOGUE</a></button></li>
					<li>
<button  style="width:auto;"><a href="destroy.php" style="text-decoration:none;color:white;">LOGOUT </a></button></li>
					
					</div>  
				</ul>
			
		


<div id="id01" class="modal">
  <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">&times;</span>
  <form class="modal-content" action="login.php" enctype="multipart/form-data" method="post">
    <div class="container">
      <h1>Login</h1>
      
	
   
	
      
      <label for="username"><b>Your Email Address</b></label><br>
      <input type="text"  placeholder="Enter email" name="username" required>


<br>
	


      <label for="psw"><b>Enter Password</b></label><br>
      <input type="password"  placeholder="Enter password" name="psw" required>
	
	<br>
      
      <label>
        <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
      </label>
<br>

      <div class="clearfix">
        <button type="button" style="width:300px;" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn">Cancel</button>
        <button type="submit" style="width:300px;" class="signupbtn">Login</button>
      </div>
    </div>
  </form>
</div>














			<div id="header" style="text-align:center;">
			
        			<div id="headerTitle" style="float:left"><a href="cust_category.php"><img src="images/homepage/goodbuy.jpg"></a></div><br><br>

	 <a href="viewcart.php" style="float:right;" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-shopping-cart"></span> Shopping Cart
        </a><br><br><br><br>
				<div id="search" style="float:center;display:inline;vertical-align: middle;" >
		<form class="example" action="/action_page.php" style="margin:auto;max-width:300px;">
  <input type="text" placeholder="Search for products,brands and more..." name="search2">
  
</form>				</div>
		</div>
   			<br>
			<div id="nav">
				<ul style="font-size:15px;text-decoration:none;">
					<li><a href="">ELECTRONICS</a></li>
					<li><a href="">APPLIANCES</a></li>
					<li><a href="">MEN</a></li>
					<li><a href="">WOMEN</a></li>
					<li><a href="">BABY&KIDS</a></li>
					<li><a href="">HOME&FURNITURE</a></li>
					<li><a href="">SPORTS,BOOKS&MORE</a></li>
					<li><a href="">OFFER ZONE</a></li>
				</ul>
			</div>



		</div>
		<div id="content" style="text-align:center;overflow:visible;height:500px;">
                    <div class="zoomin">
			<div class="article column1">
				<a href="fpage_women.html"><img src="images/homepage/f1.jpg"></a>
				<form class="but" action="fpage_women.html">
    					<input type="submit" value="WOMEN'S FASHION" />
				</form>
			</div>
			<div class="article column2">
				<a href="fpage_men.html"><img src="images/homepage/men2.jpg"></a>
				<form class="but" action="fpage_men.html"><br>
    					<input type="submit" value="MEN'S FASHION" />
				</form>
				
			</div>
			<div class="article column3">
				<a href="fpage_mob.html"><img src="images/homepage/mob.jpg"></a>
				<form class="but" action="fpage_mob.html"><br>
    					<input type="submit" value="MOBILES" />
				</form>
			</div>
			<div class="article column4">
				<a href="fpage_baby.html"><img src="images/homepage/babyc.jpg"></a>
				<form class="but" action="fpage_baby.html"><br>
    					<input type="submit" value="BABY CARE" />
				</form>
			</div>
			<div class="article column5">
				<a href="fpage_gift.html"><img src="images/homepage/gift.jpg"></a>
				<form class="but" action="fpage_gift.html"><br>
    					<input type="submit" value="GIFTS" />
				</form>
			</div>
			<div class="article column1">
				<a href="fpage_paint.html"><img src="images/homepage/paint.jpg"></a>
				<form class="but" action="fpage_paint.html">
    					<input type="submit" value="PAINTINGS" />
				</form>
			</div>
			
			<div class="article column2">
				<a href="fpage_kid.html"><img src="images/homepage/kid.jpg"></a>
				<form class="but" action="fpage_kid.html">
					<br>
    					<input type="submit" value="KIDS" />
				</form>
			</div>
			<div class="article column3">
				<a href="fpage_women.html"><img src="images/homepage/book.jpg"></a>
				<form class="but" action="fpage_book.html"><br>
    					<input type="submit" value="BOOKS" />
				</form>
			</div>
			<div class="article column4">
				<a href="fpage_jewel.html"><img src="images/homepage/jewel.jpg"></a>
				<form class="but" action="fpage_jewel.html">
    					<input type="submit" value="JEWELLERY" />
				</form>
			</div>
			<div class="article column5">
				<a href="fpage_opticals.html"><img src="images/homepage/glass.jpg"></a>
				<form class="but" action="fpage_opticals.html">
    					<input type="submit" value="OPTICALS" />
				</form>
			</div>
			
			
			
		</div>
          </div>
		
		


		
			
			

 
		
		
		<div id="downtips">
		

<h3>Accepted Payment Methods </h3>
<p><a href="#"><img src="images/homepage/payment_methods.png" alt="payment methods"/></a></p><br><br>



		</div>

			
				<div id="footer">
 
				<h3 align="center">CONTACT WITH US </h3>
				<center>
				<div id="p">
	     <div id="f"> <a href="#"><img width="60" height="60" src="images/homepage/facebook.png" title="facebook" alt="facebook"/></a></div>
				<div id="t"> <a href="#"><img width="60" height="60" src="images/homepage/twitter.png" title="twitter" alt="twitter"/></a></div>
			<div id="y"> 	<a href="#"><img width="60" height="60" src="images/homepage/youtube.png" title="youtube" alt="youtube"/></a></div></div></center>


                              <p><center><a href="#">Terms and condition.</a> &copy; Copyright 2018</center></p>
			 </div> 
    </div>
			
		</div>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>


	</body>
</html>

