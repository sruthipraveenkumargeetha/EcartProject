<?php
session_start();

?>

<html>
<head>
<style>



.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
fieldset{
display: inline-block;

}
fieldset
{
    height:400px;
    width: 30%;
    background: #ffffff;
    text-align:center;
    margin:50px 50px 50px 450px;
}
body{font-size:20px;font-family:Comic Sans MS;background-color:#efefef;}


</style>
</head>
<body>
<?php
$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username=$_POST["username"];

$_SESSION["email"]=$username;

$sql= "SELECT * FROM customer WHERE email='$username'";




$result = $conn->query($sql);
if($result->num_rows > 0)
{
	while($row = $result->fetch_assoc()) {


$_SESSION["fname"]=$row["fname"];
$_SESSION["email"]=$row["email"];$_SESSION["sec"]=$row["securityqn"];$_SESSION["ans"]=$row["answer"];
  $_SESSION["phone"]=$row["mob"];
  $_SESSION["gender"]=$row["gender"];
  $_SESSION["psw"]=$row["password"];$_SESSION["path"]=$row["path"];$_SESSION["custid"]=$row["id"];
 $_SESSION["lname"]=$row["lname"]; $_SESSION["dob"]=$row["dob"]; $_SESSION["bio"]=$row["bio"]; $_SESSION["addr"]=$row["addr"]; 

    }



    


}
else
    echo "Not a registered user!";





$conn->close();
?>


<form action="confirm.php" enctype="multipart/form-data" method="post">
 <fieldset>
  <br><br><br><br>
  <?php echo $_SESSION["sec"];?> <input type="text" name="reply" required><br><br><br><br><br>
  <input type="submit" class="button" value="Verify Answer">
 </fieldset>
</form>


</body>
</html>












