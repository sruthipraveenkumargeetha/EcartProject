<?php
// Start the session
session_start();
?>



<html>
<head>
<script type="text/javascript" src="table_script.js"></script>

</head>
<body>
<div id="wrapper">
<table align='center' cellspacing=2 cellpadding=5 id="data_table" border=1>
<tr>
<th>CATEGORY ID</th>
<th>CATEGORY NAME</th>
<th>OPTIONS</th>
</tr>

<tr id="row1">
<td id="name_row1">1</td>
<td id="country_row1">Women's Fashion</td>

<td>
<input type="button" id="edit_button1" value="Edit" class="edit" onclick="edit_row('1')">
<input type="button" id="save_button1" value="Save" class="save" onclick="save_row('1')">
<input type="button" value="Delete" class="delete" onclick="delete_row('1')">
</td>
</tr>

<tr id="row2">
<td id="name_row2">2</td>
<td id="country_row2">Men's Fashion</td>

<td>
<input type="button" id="edit_button2" value="Edit" class="edit" onclick="edit_row('2')">
<input type="button" id="save_button2" value="Save" class="save" onclick="save_row('2')">
<input type="button" value="Delete" class="delete" onclick="delete_row('2')">
</td>
</tr>

<tr id="row3">
<td id="name_row3">3</td>
<td id="country_row3">Mobiles</td>

<td>
<input type="button" id="edit_button3" value="Edit" class="edit" onclick="edit_row('3')">
<input type="button" id="save_button3" value="Save" class="save" onclick="save_row('3')">
<input type="button" value="Delete" class="delete" onclick="delete_row('3')">
</td>
</tr>

<tr id="row4">
<td id="name_row4">4</td>
<td id="country_row4">Baby Care</td>

<td>
<input type="button" id="edit_button4" value="Edit" class="edit" onclick="edit_row('4')">
<input type="button" id="save_button4" value="Save" class="save" onclick="save_row('4')">
<input type="button" value="Delete" class="delete" onclick="delete_row('4')">
</td>
</tr>

<tr id="row5">
<td id="name_row5">5</td>
<td id="country_row5">Gifts</td>

<td>
<input type="button" id="edit_button5" value="Edit" class="edit" onclick="edit_row('5')">
<input type="button" id="save_button5" value="Save" class="save" onclick="save_row('5')">
<input type="button" value="Delete" class="delete" onclick="delete_row('5')">
</td>
</tr>

<tr id="row6">
<td id="name_row6">6</td>
<td id="country_row6">Paintings</td>

<td>
<input type="button" id="edit_button6" value="Edit" class="edit" onclick="edit_row('6')">
<input type="button" id="save_button6" value="Save" class="save" onclick="save_row('6')">
<input type="button" value="Delete" class="delete" onclick="delete_row('6')">
</td>
</tr>


<tr id="row7">
<td id="name_row7">7</td>
<td id="country_row7">Kids</td>

<td>
<input type="button" id="edit_button7" value="Edit" class="edit" onclick="edit_row('7')">
<input type="button" id="save_button7" value="Save" class="save" onclick="save_row('7')">
<input type="button" value="Delete" class="delete" onclick="delete_row('7')">
</td>
</tr>


<tr id="row8">
<td id="name_row8">8</td>
<td id="country_row8">Books</td>

<td>
<input type="button" id="edit_button8" value="Edit" class="edit" onclick="edit_row('8')">
<input type="button" id="save_button8" value="Save" class="save" onclick="save_row('8')">
<input type="button" value="Delete" class="delete" onclick="delete_row('8')">
</td>
</tr>



<tr id="row9">
<td id="name_row9">9</td>
<td id="country_row9">Jewellery</td>

<td>
<input type="button" id="edit_button9" value="Edit" class="edit" onclick="edit_row('9')">
<input type="button" id="save_button9" value="Save" class="save" onclick="save_row('9')">
<input type="button" value="Delete" class="delete" onclick="delete_row('9')">
</td>
</tr>


<tr id="row10">
<td id="name_row10">10</td>
<td id="country_row10">Opticals</td>

<td>
<input type="button" id="edit_button10" value="Edit" class="edit" onclick="edit_row('10')">
<input type="button" id="save_button10" value="Save" class="save" onclick="save_row('10')">
<input type="button" value="Delete" class="delete" onclick="delete_row('10')">
</td>
</tr>
<tr>
<td><input type="text" id="new_name"></td>
<td><input type="text" id="new_country"></td>

<td><input type="button" class="add" onclick="add_row();" value="Add CAtegory"></td>
</tr>



</table>
</div>

</body>
</html>
