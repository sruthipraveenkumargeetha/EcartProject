<php?
session_start();
?>


<html>
<head>

<style>

 
*{
font-family: Comic Sans MS;

}
body{
background-color:#efefef;
}
img{border-radius:20%;}
td{text-align:center;
}
table,td,th{
border-collapse:collapse;
}
table,th{border:none;}
</style>
</head>
</html>

<html>
<head>
<style>
.button1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.button2{
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;
background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;

}
</style>
</head>
<body>
<a href='cust_category.php' class='button1'>BACK TO CATALOGUE</a>
<a href='edit_cart.php' class='button1'>EDIT CART</a>

<a href='homepage.php' class='button2'>LOG OUT</a>
</body>
</html>


<?php
session_start();

echo "				
				<div class='full-width-background fwb-red'></div>";

			
$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$custid=$_SESSION["email"];
$sql="SELECT * FROM cart where customer_id ='$custid'";
$category=1;
$result=$conn->query($sql);
echo "<form action='purchase.php' method='post'>";

echo "<table align='center' border='1' width='90%' cellpadding='10'>";
//echo "<th> DISPLAY </th>  <th> TITLE </th>  <th> ID </th> <th>SIZES AVAILABLE </th>";

if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{	echo "<tr>";
		$name=$row["itemname"];$rate=$row["itemrate"];$path=$row["path"];$id=$row["itemid"];
		
		echo "<td width='30%'>$id</td>  <td width='30%'> $name</td> <td width='30%'>$rate</td>
		 <td width='40%'><img src=$path>PURCHASE<input type='checkbox' name='bag[]' value=$id />
</td>  <br><br> ";
	
		echo "</tr>";
		
        }
echo "</table>";
     echo "<input type='submit' name='formSubmit' value='CONFIRM ACTION' class='button1'/>";   
}
else
        echo "<h3><marquee>CART EMPTY!!!</marquee></h3><br><br>";



$conn->close() ;

?>

