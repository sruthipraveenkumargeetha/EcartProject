<?php
// Start the session
session_start();
?>



<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$cart = $_POST['cart'];

  if(empty($cart))

  {
 //header("Location: view_cart.php");
    

  }

  else

  {

    $N = count($cart);

 

    for($i=0; $i < $N; $i++)

    {

$itemid=$cart[$i];
$itemcategory="WOMEN FASHION";
$categoryid=1;

$sql="SELECT * FROM women WHERE itemid='$itemid' ";

$result=$conn->query($sql);

if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{	
		$itemname=$row["itemname"];$itemrate=$row["itemrate"];$path=$row["path"];$custid=$_SESSION["email"];

		$sql1="INSERT INTO cart (itemname,itemid,itemcategory,itemrate,customer_id,categoryid,path)
		VALUES ('$itemname','$itemid','$itemcategory','$itemrate','$custid','$categoryid','$path');";
		if($conn->query($sql1) === TRUE) {
 
   				
		}
		else
			echo "Error: " . $sql1 . "<br>" . $conn->error;
		
		
        }//row
header("Location: viewcart.php");
        
}//result
else
        echo "Error: " . $sql . "<br>" . $conn->error;
//----next operation

}}

$cart1 = $_POST['cart1'];

  if(empty($cart1))

  {
 header("Location: viewcart.php");
    

  }

  else

  {

    $N = count($cart1);

 

    for($i=0; $i < $N; $i++)

    {

$itemid=$cart1[$i];
$itemcategory="WOMEN FASHION";
$categoryid=1;

$sql="SELECT * FROM women WHERE itemid='$itemid' ";

$result=$conn->query($sql);

if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{	
		$itemname=$row["itemname"];$itemrate=$row["itemrate"];$path=$row["path"];$custid=$_SESSION["email"];

$sql1="INSERT INTO purchase (itemname,itemid,itemrate,custid,path)
		VALUES ('$itemname','$itemid','$itemrate','$custid','$path');";

		if($conn->query($sql1) === TRUE) {
 
   				
		}
		else
			echo "Error: " . $sql1 . "<br>" . $conn->error;
		
		
        }//row
header("Location: purchase.php");
        
}//result
else
        echo "Error: " . $sql . "<br>" . $conn->error;
















    }//forloop

  }//big else


$conn->close();
?>
