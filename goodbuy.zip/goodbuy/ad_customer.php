<php?
session_start();
?>


<html>
<head>

<style>

 
*{
font-family: Comic Sans MS;

}
body{
background-color:#efefef;
}
img{border-radius:20%;}
td{text-align:center;
}
table,td,th{
border-collapse:collapse;
}
table,th{border:none;}
</style>
</head>
</html>

<html>
<head>
<style>
.button1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.button2{
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;
background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;

}
.button3{
 margin-bottom: 50px;
     margin-right: 10px;
     position:absolute;
     bottom:0;
     right:0;
background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 12px;
    
    cursor: pointer;


}
</style>
</head>
<body>
<a href='admin_menu.html' class='button1'>BACK TO MENU</a>


<a href='homepage.php' class='button2'>LOG OUT</a>
</body>
</html>


<?php
session_start();

echo "				
				<div class='full-width-background fwb-red'></div>";

			
$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$custid=$_SESSION["email"];
$sql="SELECT * FROM customer";
$category=1;
$result=$conn->query($sql);
echo "<form action='delete_cust.php' method='post'>";

echo "<table align='center' border='1' width='90%' cellpadding='10'>";
echo "<th> CUSTOMER ID </th>  <th> CUSTOMER NAME </th>  <th> CONTACT NUMBER </th> <th>EMAIL </th> <th>DELETE </th><th> VIEW CART </th>";


$i=0;
if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{	echo "<tr>";$i=$i+1;
		$id=row["id"];$fname=$row["fname"];$mob=$row["mob"];$email=$row["email"];$email=$row["email"];
		
		echo "<td width='30%'>$i</td>  <td width='30%'> $fname</td> <td width='30%'>$mob</td><td width='30%'>$email</td>
		 <td width='40%'><input type='checkbox' name='bag[]' value=$email /></td><td><input type='checkbox' name='bag1[]' value=$email />
</td>  <br><br> ";
	
		echo "</tr>";
		
        }
        
}
else
        echo "<br><br>";
echo "</table>";
echo "<input type='submit' name='formSubmit' value='CONFIRM ACTION' class='button3'/>";
$conn->close() ;

?>

