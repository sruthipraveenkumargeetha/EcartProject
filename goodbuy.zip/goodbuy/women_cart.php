<?php
// Start the session
session_start();
?>




<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$username= $_SESSION['email'];
echo $_POST['submit'];
$sql= "SELECT id FROM customer WHERE '$username'=email;

$result = $conn->query($sql);
if($result->num_rows > 0)
{
	while($row = $result->fetch_assoc()) {
		$id=row['id'];



    }


echo $id;


}
else
    echo "failure";
    



$conn->close();
?>
<html>
<body>
<br>
<br>


</body>
</html>
