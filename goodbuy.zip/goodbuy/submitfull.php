<?php
// Start the session
session_start();
?>




<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$fname=$_POST["fname"];


$phone=$_POST["phone"];

$gender=$_POST["gender"];
$psw=$_POST["psw"];
$email=$_POST["email"];
$lname=$_POST["lname"];




$dob=$_POST["dob"];
$addr=$_POST["addr"];
$sec=$_POST["sec"];
$ans=$_POST["ans"];
  $_SESSION["lname"]=$lname;
  $_SESSION["bio"]=$bio;
  $_SESSION["dob"]=$dob;
  $_SESSION["addr"]=$addr;

 $_SESSION["fname"]=$fname;
  $_SESSION["phone"]=$phone;
  $_SESSION["gender"]=$gender;
  $_SESSION["psw"]=$psw;
$_SESSION["sec"]=$sec;
$_SESSION["ans"]=$ans;
$sql = "UPDATE customer SET fname='$fname',lname='$lname',dob='$dob',mob='$phone',password='$psw',addr='$addr',gender='$gender',securityqn='$sec',answer='$ans' WHERE email='$email'";




if ($conn->query($sql) === TRUE) {
     header("Location: first_page.php");
} else {
       echo "Error: " . $sql . "<br>" . $conn->error;
}


$conn->close();
?>
<html>
<body>
<br>
<br>


</body>
</html>
