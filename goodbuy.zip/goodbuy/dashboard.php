<?php
// Start the session
session_start();
?>



<html>
<head>
<style>
	body{
		font-family:"Comic Sans MS";}
input,select{

border-radius: 5px;
}
select{
width: 210px;}
.curso {cursor: pointer;}
.button1 {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;
}
.button2 {
 margin-top: 10px;
     margin-right: 10px;
     position:absolute;
     top:0;
     right:0;
 background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    
    cursor: pointer;

}
</style>
</head>
<body>
<a href='cust_category.php' class='button1'>BACK TO CATALOGUE</a>


<a href='homepage.php' class='button2'>LOG OUT</a>
<form action="submitfull.php" name="eidt" method="POST" >
<center>
<table style="padding: 5px 5px 5px 10px;" width="100%" height="100%" bgcolor="#efefef" align="center"
cellspacing="2">

<tr>
<td colspan=2 >
<center><font size=4><b><h1>Personal Details</h1></b></font></center>
</td>
</tr>

<tr>
<td>First Name</td>
<td><input  type=text name=fname  size="30" value="<?php echo $_SESSION['fname'];?>"</td>
</tr>

<tr>
<td>Last Name</td>
<td><input type="text" name="lname"  value="<?php echo $_SESSION['lname'];?>"
size="30"></td>
</tr>


<tr>
<td>Date Of Birth</td>
 
<td><input type="text" name="dob"  value="<?php echo $_SESSION['dob'];?>"
size="30"></td>

 


 
<tr>
<td>Address</td>
<td><input  type="text" name="addr" value="<?php echo $_SESSION['addr'];?>"  size="30"></td>
</tr>









<tr>
<td>Gender</td>
<td>  <input type="radio" name="gender" <?php if (isset($_SESSION['gender']) && $_SESSION['gender']=="female") echo "checked";?> value="female">Female
  <input type="radio" name="gender" <?php if (isset($_SESSION['gender']) && $_SESSION['gender']=="male") echo "checked";?> value="male">Male </td>
</tr>








<tr>
<td>MobileNo</td>
<td><input  type="text" name="phone" value="<?php echo $_SESSION['phone'];?>"  size="30"></td>
</tr>




<tr>
<td>Email id</td>
<td><input  type="text" name="email" value="<?php echo $_SESSION['email'];?>"  size="30" readonly></td>
</tr>


<tr>
<td>Password</td>
<td><input  type="text" name="psw" value="<?php echo $_SESSION['psw'];?>"  size="30"></td>
</tr>
<tr>
<td>Security Question</td>
<td><input  type="text" name="sec" value="<?php echo $_SESSION['sec'];?>"  size="30"></td>
</tr>
 <tr>
<td>Answer for Security Question</td>
<td><input  type="text" name="ans" value="<?php echo $_SESSION['ans'];?>"  size="30"></td>
</tr>
<tr>

<td><br /><input type="reset" class="curso"></td>
<td colspan="2"><br /><input type="submit" value="Update Dashboard"/></td>
</tr>





</table>
</center>
</form>
</body>
</html>
