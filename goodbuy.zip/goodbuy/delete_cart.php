<?php
// Start the session
session_start();
?>



<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$bag = $_POST['bag'];

  if(empty($bag))

  {
header("Location: viewcart.php");

  }

  else

  {

    $N = count($bag);

 

    for($i=0; $i < $N; $i++)

    {

$itemid=$bag[$i];


$sql="select itemid,itemname,path,itemrate from women where itemid='$itemid';
 ";

$result=$conn->query($sql);

if($result->num_rows>0)
{
	while($row=$result->fetch_assoc())
	{	
		$itemname=$row["itemname"];$itemrate=$row["itemrate"];$path=$row["path"];$custid=$_SESSION["email"];
		$itemid=$row["itemid"];
		
		$sql2="DELETE FROM cart where itemid =$itemid";
		if($conn->query($sql2) === TRUE) {
 
   				//header("Location: transaction.php");
		}
		else
			echo "Error: " . $sql2 . "<br>" . $conn->error;
		
		
        }//row
        
}//result
else
        echo "Error: " . $sql . "<br>" . $conn->error;


    }//forloop

  }//big else
header("Location: viewcart.php");
//header("Location: viewcart.php");
$conn->close();
?>
