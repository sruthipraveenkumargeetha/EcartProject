<?php
// Start the session
session_start();
?>




<?php

$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$_SESSION['dob']="";
$_SESSION['addr']="";
$_SESSION['lname']="";
$_SESSION['path']="nodp.png";
$fname=$_POST["fname"];
$email=$_POST["email"];

$phone=$_POST["phone"];

$gender=$_POST["gender"];
$psw=$_POST["psw"];
$sql="INSERT INTO customer (gender,mob,email,password,fname,path)
VALUES ('$gender','$phone','$email','$psw','$fname','nodp.png');";
if($conn->query($sql) === TRUE) {
  $_SESSION["fname"]=$fname;
  $_SESSION["email"]=$email;
  $_SESSION["phone"]=$phone;
  $_SESSION["gender"]=$gender;
  $_SESSION["psw"]=$psw;
   header("Location: first_page.php");
}
else
echo "Error: " . $sql . "<br>" . $conn->error;









$sql= "SELECT * FROM customer WHERE '$username'=email ";

$result = $conn->query($sql);
if($result->num_rows > 0)
{
	while($row = $result->fetch_assoc()) {
		$_SESSION["custid"]=$row["id"];




    }




}

























$conn->close();
?>
<html>
<body>
<br>
<br>


</body>
</html>
