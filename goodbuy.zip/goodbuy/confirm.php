<?php
// Start the session
session_start();


$servername = "localhost";
$user = "root";
$pass = "akcspg36883";
$dbname="goodbuy";

$conn = new mysqli($servername,$user,$pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$reply = $_POST['reply'];
$answer=$_SESSION['ans'];
 //echo "reply".$reply."answers ".$answer." ".$_SESSION["email"];































if($reply==$answer)


header("Location: changepassword.php");

else

header("Location: login_error.html");
$conn->close();
?>
