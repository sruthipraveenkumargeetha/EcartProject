<?php

session_start();
?>


<!DOCTYPE html>
<html>
<style>

.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
fieldset{
display: inline-block;

}
fieldset
{
    height:400px;
    width: 30%;
    background: #ffffff;
    text-align:center;
    margin:50px 50px 50px 450px;
}
body{font-size:20px;font-family:Comic Sans MS;background-color:#efefef;}
</style>

<script type="text/javascript">

function pvalidate() {

if (document.registration.p1.value != document.registration.p2.value)

{

        alert('Passwords did not match!');

        return true;

    }

else

{

return true;

}

</script>

<body>

<form action="submit_password.php" enctype="multipart/form-data" method="post" name="registration" onsubmit="pvalidate()">
 <fieldset>
  <legend align="center">Change Password</legend><br><br><br><br>
  Enter new password : <input type="password" name="p1" required><br><br><br><br><br>
 Re-enter password : <input type="password" name="p2" required><br><br><br><br><br>
  <input type="submit" class="button" value="Update new password">
 </fieldset>
</form>

</body>
</html>
<?php
$email=$_SESSION["email"];
$sql= "SELECT * FROM customer WHERE email='$email'";




$result = $conn->query($sql);
if($result->num_rows > 0)
{
	while($row = $result->fetch_assoc()) {

$_SESSION["fname"]=$row["fname"];
$_SESSION["email"]=$row["email"];$_SESSION["sec"]=$row["securityqn"];$_SESSION["ans"]=$row["answer"];
  $_SESSION["phone"]=$row["mob"];
  $_SESSION["gender"]=$row["gender"];
  $_SESSION["psw"]=$row["password"];$_SESSION["path"]=$row["path"];$_SESSION["custid"]=$row["id"];
 $_SESSION["lname"]=$row["lname"]; $_SESSION["dob"]=$row["dob"]; $_SESSION["bio"]=$row["bio"]; $_SESSION["addr"]=$row["addr"]; 

    }



    


}


?>

